create
    definer = `mysql.sys`@localhost function ps_is_instrument_default_enabled(in_instrument varchar(128)) returns enum ('YES', 'NO')
    comment '
 Description
 
 Returns whether an instrument is enabled by default in this version of MySQL.
 
 Parameters
 
 in_instrument VARCHAR(128): 
 The instrument to check.
 
 Returns
 
 ENUM(''YES'', ''NO'')
 
 Example
 
 mysql> SELECT sys.ps_is_instrument_default_enabled(''statement/sql/select'');
 +--------------------------------------------------------------+
 | sys.ps_is_instrument_default_enabled(''statement/sql/select'') |
 +--------------------------------------------------------------+
 | YES                                                          |
 +--------------------------------------------------------------+
 1 row in set (0.00 sec)
 '
    deterministic
    sql security invoker
    reads sql data
BEGIN DECLARE v_enabled ENUM('YES', 'NO');  SET v_enabled = IF(in_instrument LIKE 'wait/io/file/%' OR in_instrument LIKE 'wait/io/table/%' OR in_instrument LIKE 'statement/%' OR in_instrument LIKE 'memory/performance_schema/%' OR in_instrument IN ('wait/lock/table/sql/handler', 'idle')  OR in_instrument LIKE 'stage/innodb/%' OR in_instrument = 'stage/sql/copy to tmp table'  , 'YES', 'NO' );  RETURN v_enabled; END;

