create definer = `mysql.sys`@localhost view user_summary_by_stages as
select if(isnull(`performance_schema`.`events_stages_summary_by_user_by_event_name`.`USER`), 'background',
          `performance_schema`.`events_stages_summary_by_user_by_event_name`.`USER`)                            AS `user`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`EVENT_NAME`                          AS `event_name`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`COUNT_STAR`                          AS `total`,
       `sys`.`format_time`(`performance_schema`.`events_stages_summary_by_user_by_event_name`.`SUM_TIMER_WAIT`) AS `total_latency`,
       `sys`.`format_time`(`performance_schema`.`events_stages_summary_by_user_by_event_name`.`AVG_TIMER_WAIT`) AS `avg_latency`
from `performance_schema`.`events_stages_summary_by_user_by_event_name`
where (`performance_schema`.`events_stages_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` <> 0)
order by if(isnull(`performance_schema`.`events_stages_summary_by_user_by_event_name`.`USER`), 'background',
            `performance_schema`.`events_stages_summary_by_user_by_event_name`.`USER`),
         `performance_schema`.`events_stages_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` desc;

