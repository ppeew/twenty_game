create definer = `mysql.sys`@localhost view io_global_by_file_by_latency as
select `sys`.`format_path`(`performance_schema`.`file_summary_by_instance`.`FILE_NAME`)       AS `file`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_STAR`                           AS `total`,
       `sys`.`format_time`(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WAIT`)  AS `total_latency`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_READ`                           AS `count_read`,
       `sys`.`format_time`(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_READ`)  AS `read_latency`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_WRITE`                          AS `count_write`,
       `sys`.`format_time`(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WRITE`) AS `write_latency`,
       `performance_schema`.`file_summary_by_instance`.`COUNT_MISC`                           AS `count_misc`,
       `sys`.`format_time`(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_MISC`)  AS `misc_latency`
from `performance_schema`.`file_summary_by_instance`
order by `performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WAIT` desc;

