create definer = `mysql.sys`@localhost view x$host_summary_by_file_io as
select if(isnull(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`HOST`), 'background',
          `performance_schema`.`events_waits_summary_by_host_by_event_name`.`HOST`)            AS `host`,
       sum(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`COUNT_STAR`)     AS `ios`,
       sum(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`SUM_TIMER_WAIT`) AS `io_latency`
from `performance_schema`.`events_waits_summary_by_host_by_event_name`
where (`performance_schema`.`events_waits_summary_by_host_by_event_name`.`EVENT_NAME` like 'wait/io/file/%')
group by if(isnull(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`HOST`), 'background',
            `performance_schema`.`events_waits_summary_by_host_by_event_name`.`HOST`)
order by sum(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`SUM_TIMER_WAIT`) desc;

